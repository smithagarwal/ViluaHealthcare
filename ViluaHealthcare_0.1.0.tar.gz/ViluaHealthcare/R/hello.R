#' hello function - prints a welcome message by Vilua
#' @return value
#' @export

hello <- function() {
  print("Welcome to Vilua Healthcare Gmbh")
}
